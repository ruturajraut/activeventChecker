var AWS = require("aws-sdk");
var https = require('https');
var mysql = require('mysql');

var ses = new AWS.SES({ region: 'ap-south-1' });

exports.handler = (event, context, callback) => {
    if (!event.hasOwnProperty("activevent_checker")) {
        callback("Valid parameter not found");
        return;
    }

    const connection = mysql.createConnection({
        host: "claypot-db-instance.ci3ywfy1btrn.ap-south-1.rds.amazonaws.com",
        user: "claypot_db_user",
        password: "claypot_db_user_password",
        database: "claypot_db"
    });
    
    var teleerrorlist = [];
    var emailerrorlist = [];
    var subject = 'Problem Detected with Activevent data:'
    var emailIDArr = [
                        "ruturajraut2000@gmail.com",
                        "gautam@claypot.in",
                        //"chauhan@claypot.in",
                        //"tech-assist@claypot.in",
                        //"yogesh@claypot.in"
                        
                    ];
    connection.connect(err => {
        if (err) {
            console.error('Error connecting to MySQL', err);
            callback(err);
            return;
        }
        
        const now = new Date();
        now.setTime(now.getTime() + (5 * 60 * 60 * 1000) + (30 * 60 * 1000));
        let year = now.getFullYear();
        
        console.log("Now:",now)
        
         // Define the start and end time of the time window (8:30 am to 6:30 pm) /---
        var startTime = new Date(now);
        startTime.setHours(8, 0, 0, 0); // Set to 8:30 am
        var endTime = new Date(now);
        endTime.setHours(18, 30, 0, 0); // Set to 6:30 pm  18:30
        
        let month = now.getMonth() + 1;
        let day = now.getDate();
        let hour = now.getHours();
        
        if(month < 10){month = "0" + month};
        if(day < 10){day = "0" + day};
        if(hour < 10){hour = "0" + hour};
        
        const dateTimeString = year + "-" + month + "-" + day + " " + hour;
        const dateString = year + "-" + month + "-" + day;
        
        console.log("DAte Time String",dateTimeString)
        console.log("Date String", dateString)
        
        // Query to check the status of AHUs
        const ahuQuery = `SELECT ahu_id, run_status FROM claypot_db.quantum_ahu WHERE dt LIKE '${dateTimeString}%'`;

        // Query to check the status of activevents
        const activeventQuery = `SELECT device_id, run_status FROM claypot_db.quantum_activevent WHERE dttm LIKE '${dateTimeString}%'`;

        connection.query(ahuQuery, (errAhu, resultsAhu) => {
            if (errAhu) {
                console.error('Error executing AHU query', errAhu);
                callback(errAhu);
                return;
        }
    
        console.log("AHU query executed successfully:", resultsAhu);
        
        // check latest entry for ahu
        if (resultsAhu.length === 0) {
        // No latest entry for AHUs, send an alert email
        emailerrorlist.push("No latest entry found for AHUs");
        sendMail(emailerrorlist, callback);
        return;
    }

        
        // Print AHU statuses
        const ahuStatuses = {};
        
        resultsAhu.forEach(row => {
            ahuStatuses[row.ahu_id] = row.run_status;
            console.log("AHU ID:", row.ahu_id, "Status:", row.run_status);
          
            
        });
        
       
        
        // Execute the activevent query
        connection.query(activeventQuery, (errActivevent, resultsActivevent) => {
            if (errActivevent) {
                console.error('Error executing activevent query', errActivevent);
                callback(errActivevent);
                return;
            }
            
        console.log("Activevent query executed successfully:", resultsActivevent);
        
        
        //check latest entry for activevent
        if (resultsActivevent.length === 0) {
            // No latest entry for activevents, send an alert email
            emailerrorlist.push("No latest entry found for activevents");
            sendMail(emailerrorlist, callback);
            return;
        }
        
        // Print activevent statuses
        const activeventStatuses = {};
        resultsActivevent.forEach(row => {
            activeventStatuses[row.device_id] = row.run_status;
            console.log("Activevent Device ID:", row.device_id, "Status:", row.run_status);
        });
        
        console.log("resultsAhu[0]",resultsAhu[0])   //bayerAhu1
        console.log("resultsAhu[0].run_status",resultsAhu[0].run_status)
        
        console.log("resultsAhu[1]",resultsAhu[1])   //bayerAhu2
        console.log("resultsAhu[1].run_status",resultsAhu[1].run_status)
        
        console.log("resultsAhu[2]",resultsAhu[2])   //solusAhu1
        console.log("resultsAhu[2].run_status",resultsAhu[2].run_status)
        
        console.log("resultsAhu[3]",resultsAhu[3])   //solusAhu2
        console.log("resultsAhu[3].run_status",resultsAhu[3].run_status)
        
        
        console.log("resultsActivevent[0]",resultsActivevent[0])  //solusActiveVent
        console.log("resultsActivevent[0].run_status",resultsActivevent[0].run_status)
        
        console.log("resultsActivevent[1]",resultsActivevent[1])  //bayerActiveVent
        console.log("resultsActivevent[1].run_status",resultsActivevent[1].run_status)
        
        // Check solus AHUs, bayer AHUs and their corresponding Activevent
        if (resultsAhu[0].run_status === 1 && resultsAhu[1].run_status === 1) {   // bayerAhu1  and bayerAhu2
            if (resultsActivevent[1].run_status !== 1) {
                emailerrorlist.push(`<br> Both bayer AHUs having id : ${resultsAhu[0].ahu_id} and ${resultsAhu[1].ahu_id}  are ON, but bayerActiveVent is OFF </b><br>`);
                teleerrorlist.push(`\n Both bayer AHUs having id : ${resultsAhu[0].ahu_id} and ${resultsAhu[1].ahu_id}  are ON, but bayerActiveVent is OFF \n\n`)
            }
        } else if (resultsAhu[0].run_status === 0 && resultsAhu[1].run_status === 0) {  
            if (resultsActivevent[1].run_status === 1) {
                emailerrorlist.push(`<br>Both bayer AHUs having id : ${resultsAhu[0].ahu_id} and ${resultsAhu[1].ahu_id} are OFF, but bayerActiveVent is ON</b><br>`);
                teleerrorlist.push(`\n Both bayer AHUs having id : ${resultsAhu[0].ahu_id} and ${resultsAhu[1].ahu_id} are OFF, but bayerActiveVent is ON \n\n`)
            }
        } else if ((resultsAhu[0].run_status === 1 && resultsAhu[1].run_status === 0) || (resultsAhu[0].run_status === 0 && resultsAhu[1].run_status === 1)) {
            if (resultsActivevent[1].run_status !== 1) {
                emailerrorlist.push(`<br> At least one bayer AHU is ON, but bayerActiveVent is OFF </b><br>`);
                teleerrorlist.push(`\n At least one bayer AHU is ON, but bayerActiveVent is OFF \n\n`)
            }
        }
        
        
        if (resultsAhu[2].run_status === 1 && resultsAhu[3].run_status === 1) {   // solusAhu1  and solusAhu2
            if (resultsActivevent[0].run_status !== 1) {
                emailerrorlist.push(`Both solus AHUs having id : ${resultsAhu[2].ahu_id} and ${resultsAhu[3].ahu_id}  are ON, but solusActiveVent is OFF`);
                teleerrorlist.push(`\n Both solus AHUs having id : ${resultsAhu[2].ahu_id} and ${resultsAhu[3].ahu_id}  are ON, but solusActiveVent is OFF \n\n`)
            }
        } else if (resultsAhu[2].run_status === 0 && resultsAhu[3].run_status === 0) {  
            if (resultsActivevent[0].run_status !== 0) {
                emailerrorlist.push(`Both solus AHUs having id : ${resultsAhu[2].ahu_id} and ${resultsAhu[3].ahu_id} are OFF, but solusActiveVent is ON`);
                teleerrorlist.push(`\n Both solus AHUs having id : ${resultsAhu[2].ahu_id} and ${resultsAhu[3].ahu_id} are OFF, but solusActiveVent is ON \n\n`)
            }
        } else if ((resultsAhu[2].run_status === 1 && resultsAhu[3].run_status === 0) || (resultsAhu[2].run_status === 0 && resultsAhu[3].run_status === 1)) {
            if (resultsActivevent[0].run_status !== 1) {
                emailerrorlist.push(`At least one solus AHU is ON, but solusActiveVent is OFF`);
                teleerrorlist.push(`\n At least one solus AHU is ON, but solusActiveVent is OFF \n\n`)
            }
        }
        
        console.log("Errorlstmail",emailerrorlist)
        
        

        connection.end();
            
            
        if (emailerrorlist.length > 0) {
            sendMail(emailIDArr,subject,emailerrorlist, callback);
        } else {
            console.log("Error in mail sending")
        }
        console.log("Telegram Error List ==>",teleerrorlist)
        if(teleerrorlist.length > 0){
            sendPhotoToTelegram(teleerrorlist,callback)
        
        }  
        else{
            noErrorMsgToTelegram(callback); // add callback if deleted
            
        }
        
        });
    });
    });
};

async function sendMail(emailIdArr,subject,errorlist,callback)
    {
        console.log(emailIdArr);
        // console.log(data);
        var msg = await mailcontent(errorlist); // Call mailcontent function here to get the mail message
        //console.log("---msg---",msg);
        const emailParams = {
           
            Destination: {
              //ToAddresses: ["gautam@claypot.in","yogesh@claypot.in"],
              ToAddresses: emailIdArr,
            },
            Message: {
              Body: {
                Html: { Data: msg },
              },
              Subject: { Data: subject },
            },
            Source: "octopus-alerts@octopusio.io",
        };
        console.log('after mail content');
          
        try {
            let key = await ses.sendEmail(emailParams).promise();
            console.log("MAIL SENT SUCCESSFULLY!!");
            callback(null,true);
        } catch (e) {
            //console.log("FAILURE IN SENDING MAIL!!", e);
            callback("Failure in sending mail" + e);
          }  
        return;
}

async function mailcontent(errorlist) {
    let mailContent = `<html>`;
    mailContent += `<body>`;
    mailContent += `<h2 style="color:darkgreen">Activevent  data </h2>`;
    mailContent += `<table id="octopus-table" border=1 bordercolor="#fff" cellspacing=0 cellpadding=15 style="border-radius:15px">`;
    mailContent += `<tr style="background-color:black;color:#fff" class='tableheader'>`;
    mailContent += `<th colspan=3>Activevent Alert</th>`;
    mailContent += `</tr>`;
    mailContent += `<tr style="background-color:black;color:#fff" class='tableheader'>`;
    mailContent += `<th style="text-align:center;background-color:green;color:#fff">Problem Detected with Activevent</th>`;
    mailContent += `</tr>`;

    // Append dynamic table rows based on errorlist
    errorlist.forEach(error => {
        mailContent += `<tr>`;
        mailContent += `<td style="background-color:orange;color:#fff"><b>${error}</b></td>`;
        mailContent += `</tr>`;
    });

    // Close HTML body and table tags
    mailContent += `</table>`;
    mailContent += `</body>`;
    mailContent += `</html>`;

    return mailContent;
}

async function sendPhotoToTelegram(teleerrorlist,callback) {
    // Construct the URL for the Telegram Bot API endpoint
    console.log('in telegram function')
    var photoUrl = `https://www.octopus-automation.com/apps/eqi/images/telegram/air-quality-problem.png`;
    var URLString = 'https://api.telegram.org/bot5854610426:AAF2F6aBmlNXnEUoG-Lzub7VR19UlNY21JU/sendPhoto';

    URLString +=`?chat_id=-1001640441317`; // test channel
    URLString += `&photo=${photoUrl}`;
   
    var teleerrorMessage = `Problem Detected with Activevent are as follows:\n\n${teleerrorlist.map(error => `-${error}`).join('\n\n')}`;
    var telecontent =  teleerrorMessage.split('<br>').join('')
    
   // console.log("Error msg ----+",teleerrorMessage)
    
    console.log('********',telecontent)
    // Append the error message to the URL string
    URLString += `&caption=${encodeURIComponent(telecontent)}`;
    URLString += `&parse_mode=html`;
    //console.log("URLString", URLString)

  
      // Make the HTTP request to send the photo
          // Make the HTTP request to send the photo
    const request = new https.get(URLString, (response) => {
        //console.log('in response');
        console.log('Telegram API response:', response.statusCode);
        callback(null,`Telegram response code ${response.statusCode}`);
       
    }).on('error', (error) => {
        console.error('Telegram API call Error:', error.message);   // error.message
        callback(error.message);   // same
        
    });
    
    //request.end();

    
}

async function noErrorMsgToTelegram(callback) {
    // Construct the URL for the Telegram Bot API endpoint
    var photoUrl = `https://www.octopus-automation.com/apps/eqi/images/telegram/air-quality-problem.png`;
    var URLString = 'https://api.telegram.org/bot5854610426:AAF2F6aBmlNXnEUoG-Lzub7VR19UlNY21JU/sendPhoto';

    URLString += `?chat_id=-1001640441317`; // test channel
    URLString += `&photo=${photoUrl}`;
    var telecontent =  `<b>Activevent data Checked.</b>\n\n`;
    telecontent += `No change Detected `;
    
    // Append the error message to the URL string
    URLString += `&caption=${encodeURIComponent(telecontent)}`;
    URLString += `&parse_mode=html`;

    // Make the HTTP request to send the photo
    const request = https.get(URLString, (response) => {
        console.log('Telegram API response:', response.statusCode);
        callback(null, `Telegram response code ${response.statusCode}`);
    }).on('error', (error) => {
        console.error('Telegram API call Error:', error.message);
        callback(error.message);
    });
}


